import { Component, OnInit } from '@angular/core';
import {MatDialogModule, MatDialogRef} from '@angular/material/dialog';
import { AddGroupComponent } from '../add-group/add-group.component';

@Component({
  selector: 'app-split-expense',
  templateUrl: './split-expense.component.html',
  styleUrls: ['./split-expense.component.css']
})
export class SplitExpenseComponent implements OnInit {

  groupName = "";
  members = "";
  constructor() { }

  initialGroups = [{
    groupName: "Jaipur Trip",
    members: ["Kshitij Chaudhary", "R Subburaj", "Saurabh Singh"]
  }, {
    groupName: "Agra Trip",
    members: ["Kshitij Chaudhary", "Prince Singh", "Saurabh Singh"]
  }];

 expenses = [{
   expenseName: "Tea",
   paidBy: "Kshitij",
   amount: 200,
   group:"Group 1",
   sliptType: "equal",
   membersWithExpense : [{memberName: "Kshitij", amount: 100}, {memberName: "Saurabh", amount: 100}]
 }]

 settleArr = [{settleWith: "Ajay",
 settling: "Kshitij",
 totalAmount: 3000
}]


  ngOnInit(): void {
  }

  addGroup(){
    let obj:any = {}
    obj['groupName'] = this.groupName;
    obj['members'] = this.members.split(',');

    this.initialGroups.push(obj);
  }

  addExpense(expenseName, amount, paidBy, splitType, members, group){
    let obj:any = {};
    obj["expenseName"] = expenseName;
    obj["amount"] = amount;
    obj["paidBy"] = paidBy;
    obj["sliptType"] = splitType;
    obj["group"] = group;
    let arr = []
    if(splitType === "equal"){
      let eachAmount = amount/members.length;
      members.forEach((member) => {
        arr.push({memberName: member.name, amount: eachAmount});
      })
    } else if(splitType === "custom"){
      members.forEach((member) => {
        let percent = member.percent;
        let eachAmount = amount * (percent/100);
        arr.push({memberName: member.name, amount: eachAmount});
      })
    }
    obj["membersWithExpense"] = arr;

    this.expenses.push(obj);
    this.expenses.map((expense) => {
      if(expense.expenseName === expenseName){
        expense.membersWithExpense.forEach((amt) => {
          let userAmt = amt.amount;
          this.settleArr.map((settle) => {
            if(settle.member === amt.memberName){
              settle.totalAmount += userAmt;
            }
          })
        })
      }
    })
  }

  settleExpense(user, settlewith){
    let totalAmt;
    settleArr = settleArr.map((member) => {
      if(member === settleWith){
        totalAmt = member.totalAmount;
        member.totalAmount = 0;
        return;
      }
    })
    alert(user + "Settled amount"+ totalAmt +"with"+settlewith);
  }

}
